let btn = document.querySelector("#btn");
let demo = document.querySelector("#demo");


function recuperaFile(){
    let pathFile = "./asset/mioText.txt";
    //Qui aseguo e strytytra lafetch
    //se specifico solo il url di default il metodo che utilizze la mia fetch e il metodo GET
    fetch(pathFile)
    //Questa metodo viene eseguito cuando la richista ha successo

    .then(response =>{
        //il metodo .text() cobverte in un file di testo il contenuto del mio file
        return response.text();
    })

    //Questo metodo viene eseguido dopo che ho estratta il contenudo
    .then(data =>{
        demo.innerHTML = data

    })

}

btn.addEventListener("click", recuperaFile);