let btn = document.querySelector("#btn");
let demo = document.querySelector("#demo");


let utenti = [];

function recuperaDati(){
    const URLEndopoint ="https://dummyjson.com/comments"
    fetch(URLEndopoint)
    .then(response => {
        return response.json();

    })
    .then(data => {
        console.log(data.comments);
        
        utenti = data.comments;
        console.log(utenti);

        utenti.forEach(utente => {
            demo.appendChild(creaCard(utente))
        });
        

    });

}

function creaCard(utente){
    let btnCard = document.createElement("div");
    btnCard.innerHTML = " "


    let btnUSer = document.createElement("div");
    btnUSer.innerHTML = `<ol>${utente.user.fullName}</ol>`;

    let infoAccessoria = utente.body + " "
    btnUSer.addEventListener("click", function(){
        mostraInfo(infoAccessoria)

    });
    
    btnCard.appendChild(btnUSer);
    return btnCard;
}

function mostraInfo(info){

    console.log(info);

    
    
}







btn.addEventListener("click", recuperaDati);