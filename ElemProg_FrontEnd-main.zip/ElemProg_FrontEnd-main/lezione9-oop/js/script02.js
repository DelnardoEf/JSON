let btn = document.querySelector("#btn");
let demo = document.querySelector("#demo");

let utenti = [];

function recuperaDati(){
    const URLEndopoint = "https://dummyjson.com/users";
    fetch(URLEndopoint)
    .then(response => {
        return  response.json();
    })
    .then(data => {

        //data e il "macroggetto" che recevo dell estero
        //.users e la sua prop che contiene gli utenti
        console.log(data.users);
        
        utenti = data.users;
        console.log(utenti);

        utenti.forEach(utente => {
            //demo.innerHTML += `<li> ${utente.firstName} ${utente.lastName} <img src='${utente.image}'> </li>`

            demo.appendChild(creaCard(utente))

        });

    })

   
    
}

function creaCard(utente){
    let card = document.createElement("div");
    card.innerHTML = `<li> ${utente.firstName} ${utente.lastName} <img src='${utente.image}'> </li>`
    
    let btnUser = document.createElement("button");
    btnUser.innerHTML = "Mostra info";

    let infoAccessoria = utente.age + " " + utente.phone + " " + utente.role
    btnUser.addEventListener("click", function(){
        mostraInfo(infoAccessoria)
    });
    card.appendChild(btnUser);
    return card;
}

function mostraInfo(info){
    console.log(info);
    
}



btn.addEventListener("click", recuperaDati);

