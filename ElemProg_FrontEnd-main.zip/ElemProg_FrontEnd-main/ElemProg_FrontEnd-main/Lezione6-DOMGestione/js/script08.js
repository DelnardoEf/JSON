class Utente{
    constructor(nome, cognome, corso, ruolo){
        //....
    }
}


let nome = document.querySelector("#nome").value;
let ruolo = document.querySelector("#ruolo").value;
let utente1 = new Utente()