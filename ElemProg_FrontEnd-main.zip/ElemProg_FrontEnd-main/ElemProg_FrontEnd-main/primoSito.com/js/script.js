// Commento in JS
// alert("Hello, world!");